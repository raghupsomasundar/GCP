
from google.cloud import aiplatform
import time

def log_vertex_prediction(model_id, latency_ms, token_usage):
    print({
        "model_id": model_id,
        "latency_ms": latency_ms,
        "token_usage": token_usage,
        "timestamp": time.time()
    })
