
variable "project_id" {}

resource "google_monitoring_dashboard" "agent_dashboard" {
  dashboard_json = jsonencode({
    displayName = "Enterprise Agent Dashboard"
    mosaicLayout = { tiles = [] }
  })
}
