
variable "project_id" {}

resource "google_logging_project_sink" "agent_sink" {
  name        = "agent-logs-to-bq"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/agent_logs"
  filter      = "severity>=ERROR"
  unique_writer_identity = true
}
