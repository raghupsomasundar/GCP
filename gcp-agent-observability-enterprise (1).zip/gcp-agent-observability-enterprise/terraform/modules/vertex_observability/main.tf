
variable "project_id" {}

resource "google_logging_metric" "vertex_latency" {
  name   = "vertex_latency_metric"
  filter = "resource.type=\"aiplatform.googleapis.com/Endpoint\""
}
