
variable "project_id" {}

resource "google_monitoring_alert_policy" "llm_error_rate" {
  display_name = "High LLM Error Rate"
  combiner     = "OR"

  conditions {
    display_name = "Error Rate > 5%"
    condition_threshold {
      filter          = "metric.type=\"custom.googleapis.com/agent/error_rate\""
      comparison      = "COMPARISON_GT"
      threshold_value = 5
      duration        = "120s"
    }
  }
}
