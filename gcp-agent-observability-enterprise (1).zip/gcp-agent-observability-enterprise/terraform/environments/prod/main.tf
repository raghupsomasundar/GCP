
provider "google" {
  project = var.project_id
  region  = var.region
}

module "logging" {
  source     = "../../modules/logging"
  project_id = var.project_id
}

module "monitoring" {
  source     = "../../modules/monitoring"
  project_id = var.project_id
}

module "vertex_observability" {
  source     = "../../modules/vertex_observability"
  project_id = var.project_id
}

module "alerts" {
  source     = "../../modules/alerts"
  project_id = var.project_id
}
