
import logging
import uuid
import time
import google.cloud.logging
from google.cloud.logging_v2.handlers import StructuredLogHandler

client = google.cloud.logging.Client()
handler = StructuredLogHandler()
logging.basicConfig(level=logging.INFO, handlers=[handler])
logger = logging.getLogger("agent_logger")

def log_agent_event(agent_name, session_id, step, model_name,
                    latency_ms, token_input, token_output,
                    cost_estimate, hallucination_score,
                    safety_score, tool_accuracy,
                    status, error_message=None):

    trace_id = str(uuid.uuid4())

    logger.info(
        "Agent execution event",
        extra={
            "json_fields": {
                "timestamp": time.time(),
                "agent_name": agent_name,
                "session_id": session_id,
                "trace_id": trace_id,
                "step": step,
                "model_name": model_name,
                "latency_ms": latency_ms,
                "token_input": token_input,
                "token_output": token_output,
                "cost_estimate": cost_estimate,
                "hallucination_score": hallucination_score,
                "safety_score": safety_score,
                "tool_accuracy": tool_accuracy,
                "status": status,
                "error_message": error_message,
            }
        },
    )
