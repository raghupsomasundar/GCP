
# Enterprise GCP Agent Observability

Production-ready observability stack for Agentic architectures on GCP.

Includes:
- Modular Terraform (logging, monitoring, vertex, alerts)
- Advanced LLM metrics (hallucination, safety, tool accuracy)
- Vertex AI observability hooks
- GitHub Actions CI
- Cloud Build CD

Deployment:
1. Set variables in terraform/environments/prod
2. Run terraform init && terraform apply
3. Integrate logging & metrics into agents
