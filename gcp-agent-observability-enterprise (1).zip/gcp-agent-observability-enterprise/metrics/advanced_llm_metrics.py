
from google.cloud import monitoring_v3
import time
import os

PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
client = monitoring_v3.MetricServiceClient()
project_name = f"projects/{PROJECT_ID}"

def write_metric(metric_type, value, labels=None):
    series = monitoring_v3.TimeSeries()
    series.metric.type = f"custom.googleapis.com/agent/{metric_type}"
    if labels:
        for k, v in labels.items():
            series.metric.labels[k] = v

    series.resource.type = "global"

    point = series.points.add()
    point.value.double_value = value
    point.interval.end_time.seconds = int(time.time())

    client.create_time_series(name=project_name, time_series=[series])
