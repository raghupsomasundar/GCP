
terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

module "bigquery" {
  source     = "../../modules/bigquery"
  project_id = var.project_id
  location   = var.bq_location
}

module "iam" {
  source     = "../../modules/iam"
  project_id = var.project_id
}

module "log_sinks" {
  source     = "../../modules/log_sinks"
  project_id = var.project_id
  dataset_id = module.bigquery.dataset_id
}

module "log_metrics" {
  source     = "../../modules/log_metrics"
  project_id = var.project_id
}
