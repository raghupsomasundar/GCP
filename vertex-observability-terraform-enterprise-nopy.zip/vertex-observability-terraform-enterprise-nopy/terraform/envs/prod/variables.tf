
variable "project_id" {}
variable "region" {}
variable "bq_location" { default = "US" }
