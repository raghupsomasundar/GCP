
resource "google_service_account" "obs_sa" {
  account_id   = "observability-platform-sa"
  display_name = "Observability Platform SA"
}

resource "google_project_iam_member" "secrets" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.obs_sa.email}"
}

output "sa_email" {
  value = google_service_account.obs_sa.email
}
