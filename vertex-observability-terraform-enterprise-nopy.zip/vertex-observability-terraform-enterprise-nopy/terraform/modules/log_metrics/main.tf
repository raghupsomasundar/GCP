
resource "google_logging_metric" "vertex_latency" {
  name   = "vertex_latency"
  filter = "resource.type=\"aiplatform.googleapis.com/Endpoint\""

  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "DISTRIBUTION"
    unit        = "ms"
  }
}

resource "google_logging_metric" "cloudrun_requests" {
  name   = "cloudrun_requests"
  filter = "resource.type=\"cloud_run_revision\""

  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
  }
}
