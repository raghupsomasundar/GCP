
resource "google_logging_project_sink" "all_logs" {
  name        = "all-logs-to-bq"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = ""
}

resource "google_logging_project_sink" "vertex_logs" {
  name        = "vertex-ai-logs"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = "resource.type=(\"aiplatform.googleapis.com/Endpoint\" OR \"notebook_instance\" OR \"cloud_run_revision\")"
}
