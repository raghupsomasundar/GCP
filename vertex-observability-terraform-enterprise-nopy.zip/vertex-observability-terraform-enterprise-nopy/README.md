
# Enterprise Observability Platform (No Code)

Native GCP observability using only managed services.

- Cloud Logging -> BigQuery
- Log-based metrics -> Cloud Monitoring
- GitHub Actions + Terraform
- No Python
- No Docker

Push to main branch to deploy.
