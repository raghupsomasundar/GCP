
resource "google_monitoring_alert_policy" "vertex_error_rate" {
  display_name = "Vertex AI High Error Rate"
  combiner     = "OR"

  conditions {
    display_name = "Vertex Errors > 5"
    condition_threshold {
      filter          = "metric.type=\"logging.googleapis.com/user/vertex_errors\""
      comparison      = "COMPARISON_GT"
      threshold_value = 5
      duration        = "300s"
    }
  }
}
