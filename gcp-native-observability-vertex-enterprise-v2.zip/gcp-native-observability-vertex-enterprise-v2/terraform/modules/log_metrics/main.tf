
resource "google_logging_metric" "vertex_errors" {
  name   = "vertex_errors"
  filter = "resource.type=\"aiplatform.googleapis.com/Endpoint\" AND severity>=ERROR"

  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
  }
}
