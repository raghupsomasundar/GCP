
resource "google_service_account" "observability_sa" {
  account_id   = "observability-platform-sa"
  display_name = "Observability Platform Service Account"
}

resource "google_project_iam_member" "bq_admin" {
  project = var.project_id
  role    = "roles/bigquery.admin"
  member  = "serviceAccount:${google_service_account.observability_sa.email}"
}

resource "google_project_iam_member" "logging_admin" {
  project = var.project_id
  role    = "roles/logging.admin"
  member  = "serviceAccount:${google_service_account.observability_sa.email}"
}

resource "google_project_iam_member" "monitoring_admin" {
  project = var.project_id
  role    = "roles/monitoring.admin"
  member  = "serviceAccount:${google_service_account.observability_sa.email}"
}

output "observability_sa" {
  value = google_service_account.observability_sa.email
}
