
# GCP Native Vertex AI Observability (Enterprise v2)

Service account and IAM fully managed via Terraform.

## Includes
- Service Account creation
- IAM role bindings
- Vertex AI logs -> BigQuery
- Cloud Run logs -> BigQuery
- Log-based metrics
- Alerting
- GitHub Actions CI/CD

## Deploy
1. Configure GitHub secrets:
   - WIF_PROVIDER
   - TF_DEPLOYER_SA
2. Update terraform/envs/prod/variables.tf
3. Push to main
