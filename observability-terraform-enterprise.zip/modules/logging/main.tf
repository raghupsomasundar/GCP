
resource "google_logging_project_sink" "all_logs" {
  name        = "all-logs-to-bq"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/observability"
  filter      = ""
}
