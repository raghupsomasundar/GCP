
resource "google_bigquery_dataset" "observability" {
  dataset_id = "observability"
  location   = "US"
}
