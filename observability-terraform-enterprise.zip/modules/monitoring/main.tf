
resource "google_monitoring_alert_policy" "error_logs" {
  display_name = "High Error Logs"
  combiner     = "OR"

  conditions {
    display_name = "Error logs > 10"
    condition_threshold {
      filter          = "metric.type=\"logging.googleapis.com/log_entry_count\" severity=ERROR"
      comparison      = "COMPARISON_GT"
      threshold_value = 10
      duration        = "300s"
    }
  }
}
