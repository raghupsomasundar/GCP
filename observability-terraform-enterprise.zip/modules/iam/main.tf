
resource "google_service_account" "cicd" {
  account_id   = "cicd-terraform-sa"
  display_name = "CI/CD Terraform Service Account"
}

resource "google_project_iam_member" "cicd_roles" {
  for_each = toset([
    "roles/bigquery.admin",
    "roles/logging.admin",
    "roles/monitoring.admin",
    "roles/iam.securityAdmin"
  ])
  role   = each.key
  member = "serviceAccount:${google_service_account.cicd.email}"
}
