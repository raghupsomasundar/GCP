
# Enterprise GCP Observability Terraform Repo

This repo provisions a **production-grade observability platform** for agentic / LLM workloads on GCP.

## Features
- BigQuery observability warehouse
- Cloud Logging → BigQuery sinks
- Log-based metrics
- Cloud Monitoring alerts & SLOs
- IAM with CI/CD service account
- GitHub Actions (WIF-based, no keys)
- Environment isolation (dev/test/prod ready)
