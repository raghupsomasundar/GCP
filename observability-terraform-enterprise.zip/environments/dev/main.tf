
module "iam" {
  source = "../../modules/iam"
}

module "bigquery" {
  source = "../../modules/bigquery"
}

module "logging" {
  source     = "../../modules/logging"
  project_id = var.project_id
}

module "monitoring" {
  source = "../../modules/monitoring"
}
