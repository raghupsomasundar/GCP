import json
import pandas as pd
import os

from agents.agent_runner import AgentRunner
from evaluation.llm_judge import LLMJudge
from evaluation.hallucination_detector import hallucination_score

PROJECT_ID = os.getenv("PROJECT_ID")

dataset_path = "datasets/golden_dataset.json"

with open(dataset_path) as f:
    dataset = json.load(f)

agent = AgentRunner(PROJECT_ID)
judge = LLMJudge(PROJECT_ID)

results = []

for test in dataset:

    query = test["query"]
    expected = test["expected_output"]

    response = agent.run(query)

    judge_score = judge.score(query, expected, response)

    results.append({
        "test_id": test["test_id"],
        "query": query,
        "response": response,
        "judge_score": judge_score
    })

df = pd.DataFrame(results)

df.to_csv("evaluation_results.csv", index=False)

print(df)