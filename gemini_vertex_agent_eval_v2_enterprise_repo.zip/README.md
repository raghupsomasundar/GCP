# Gemini + Vertex AI Agent Engine Evaluation Framework (Enterprise V2)

Enterprise-grade evaluation framework for agentic AI systems running on:
- Gemini models
- Vertex AI Agent Engine
- RAG systems
- Enterprise observability stacks

## Key Capabilities

- Golden dataset evaluation
- LLM-as-a-Judge scoring
- Tool-call validation
- Hallucination detection
- RAG grounding score
- Agent trace evaluation
- Synthetic test generation
- CI/CD regression testing
- BigQuery metrics storage
- Datadog / Observability hooks

## Architecture

Evaluation Types

1. Functional Testing
2. LLM Response Evaluation
3. Tool Invocation Validation
4. Grounding / Hallucination Detection
5. Business Workflow Validation

## Quick Start

Install dependencies

pip install -r requirements.txt

Set environment variables

export PROJECT_ID=<project>
export DATASET_ID=agent_eval

Run evaluation

python pipelines/run_full_evaluation.py