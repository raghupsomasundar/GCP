import logging
from google.cloud import logging as cloud_logging

def setup_logging():

    client = cloud_logging.Client()

    client.setup_logging()

    logger = logging.getLogger("agent_eval")

    return logger