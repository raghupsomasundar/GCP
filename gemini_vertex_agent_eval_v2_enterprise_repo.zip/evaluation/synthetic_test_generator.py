from vertexai.generative_models import GenerativeModel
import vertexai

class SyntheticGenerator:

    def __init__(self, project):
        vertexai.init(project=project)
        self.model = GenerativeModel("gemini-1.5-pro")

    def generate_tests(self, domain):

        prompt = f'''
        Generate 20 evaluation test queries for {domain} enterprise agent.
        Return JSON.
        '''

        result = self.model.generate_content(prompt)

        return result.text