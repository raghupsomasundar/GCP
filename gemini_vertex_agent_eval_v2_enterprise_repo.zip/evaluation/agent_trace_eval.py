def trace_score(trace_steps):

    if len(trace_steps) > 0:
        return 1

    return 0