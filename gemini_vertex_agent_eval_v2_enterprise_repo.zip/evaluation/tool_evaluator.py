def tool_accuracy(expected_tool, actual_tool):

    if expected_tool == actual_tool:
        return 1

    return 0