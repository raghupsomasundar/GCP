from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def hallucination_score(response, context):

    vectorizer = TfidfVectorizer()

    vectors = vectorizer.fit_transform([response, context])

    similarity = cosine_similarity(vectors[0:1], vectors[1:2])[0][0]

    return similarity