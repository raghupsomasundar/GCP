def grounding_score(answer, retrieved_context):

    if retrieved_context.lower() in answer.lower():
        return 1

    return 0