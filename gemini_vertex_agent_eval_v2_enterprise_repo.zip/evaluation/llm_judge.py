from vertexai.generative_models import GenerativeModel
import vertexai

class LLMJudge:

    def __init__(self, project, location="us-central1"):
        vertexai.init(project=project, location=location)
        self.model = GenerativeModel("gemini-1.5-pro")

    def score(self, query, expected, response):

        prompt = f'''
        Evaluate the agent response.

        Query: {query}

        Expected answer:
        {expected}

        Agent response:
        {response}

        Score from 1 to 5 for:

        correctness
        reasoning
        policy_compliance

        Return JSON.
        '''

        result = self.model.generate_content(prompt)

        return result.text