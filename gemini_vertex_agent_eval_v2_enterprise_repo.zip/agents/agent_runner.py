import vertexai
from vertexai.generative_models import GenerativeModel

class AgentRunner:

    def __init__(self, project, location="us-central1"):
        vertexai.init(project=project, location=location)
        self.model = GenerativeModel("gemini-1.5-pro")

    def run(self, query):

        prompt = f'''
        You are an enterprise IT and HR support agent.

        User query:
        {query}

        Respond accurately.
        '''

        response = self.model.generate_content(prompt)
        return response.text