SELECT
DATE(timestamp) as day,
COUNT(*) as total_tests,
AVG(judge_score) as avg_score
FROM agent_eval_results
GROUP BY day