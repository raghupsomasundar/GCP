
resource "google_bigquery_dataset" "obs" {
  dataset_id = "vertex_observability"
  project    = var.project_id
  location   = var.location
}
resource "google_bigquery_table" "raw_logs" {
  dataset_id = google_bigquery_dataset.obs.dataset_id
  table_id   = "raw_cloud_logs"
}
output "dataset_id" {
  value = google_bigquery_dataset.obs.dataset_id
}
