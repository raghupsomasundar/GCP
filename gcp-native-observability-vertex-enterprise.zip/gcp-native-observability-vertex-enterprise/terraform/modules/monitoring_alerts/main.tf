
resource "google_monitoring_alert_policy" "vertex_error_rate" {
  display_name = "Vertex AI High Error Rate"
  combiner = "OR"
  conditions {
    display_name = "Errors > 10 in 5 min"
    condition_threshold {
      filter          = "metric.type=\"logging.googleapis.com/user/vertex_errors\""
      comparison      = "COMPARISON_GT"
      threshold_value = 10
      duration        = "300s"
    }
  }
}
