
resource "google_logging_metric" "vertex_latency" {
  name   = "vertex_latency_ms"
  filter = "resource.type=\"aiplatform.googleapis.com/Endpoint\""
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "DISTRIBUTION"
    unit        = "ms"
  }
}
resource "google_logging_metric" "vertex_errors" {
  name   = "vertex_errors"
  filter = "resource.type=\"aiplatform.googleapis.com/Endpoint\" AND severity>=ERROR"
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
  }
}
