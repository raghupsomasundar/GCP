
resource "google_logging_project_sink" "vertex_ai" {
  name        = "vertex-ai-logs-sink"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = "resource.type=(\"aiplatform.googleapis.com/Endpoint\" OR \"notebook_instance\")"
}
resource "google_logging_project_sink" "cloudrun" {
  name        = "cloudrun-logs-sink"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = "resource.type=\"cloud_run_revision\""
}
resource "google_logging_project_sink" "all_logs" {
  name        = "all-logs-sink"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = ""
}
