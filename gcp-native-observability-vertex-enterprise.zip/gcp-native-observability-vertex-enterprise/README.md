
# GCP Native Vertex AI Observability (Enterprise)

Native GCP only. No Python. No Docker.

## Includes
- Vertex AI endpoint logs -> BigQuery
- Vertex Workbench logs -> BigQuery
- Cloud Run logs -> BigQuery
- Log-based metrics -> Cloud Monitoring
- Alerting
- Terraform + GitHub Actions

## Deploy
1. Configure GitHub secrets:
   - WIF_PROVIDER
   - TF_DEPLOYER_SA
2. Update terraform/envs/prod/variables.tf
3. Push to main branch
