def tool_accuracy(expected_tool, actual_tool):

    if expected_tool == actual_tool:
        return 1
    return 0


def task_success(response, expected_output):

    if expected_output.lower() in response.lower():
        return 1
    return 0