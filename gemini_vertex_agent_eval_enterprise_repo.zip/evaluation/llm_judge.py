from vertexai.generative_models import GenerativeModel
import vertexai

class LLMJudge:

    def __init__(self, project, location="us-central1"):
        vertexai.init(project=project, location=location)
        self.model = GenerativeModel("gemini-1.5-pro")

    def evaluate(self, query, expected, response):

        prompt = f'''
        Evaluate the following agent response.

        Query:
        {query}

        Expected Answer:
        {expected}

        Agent Response:
        {response}

        Score correctness from 1 to 5.
        Return JSON {{ "score": number }}
        '''

        result = self.model.generate_content(prompt)
        return result.text