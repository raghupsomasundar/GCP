from google.cloud import bigquery
import pandas as pd
import os

PROJECT_ID = os.getenv("PROJECT_ID")
DATASET = os.getenv("DATASET_ID")

client = bigquery.Client(project=PROJECT_ID)

df = pd.read_csv("evaluation_results.csv")

table_id = f"{PROJECT_ID}.{DATASET}.agent_eval_results"

job = client.load_table_from_dataframe(df, table_id)

job.result()

print("Results uploaded to BigQuery")