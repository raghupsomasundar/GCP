# Gemini + Vertex AI Agent Engine – Enterprise Evaluation Framework

This repository provides a production-grade evaluation framework for enterprise agentic solutions built using:
- Gemini models
- Vertex AI Agent Engine
- BigQuery for evaluation storage
- Cloud Logging / Datadog observability
- CI/CD with Cloud Build

## Features
- Golden dataset evaluation
- LLM-as-a-judge scoring using Gemini
- Tool usage evaluation
- Business workflow evaluation
- CI/CD regression testing
- Metrics persistence to BigQuery

## Repo Structure
datasets/        -> evaluation datasets
evaluation/      -> scoring logic
agents/          -> agent execution wrapper
pipelines/       -> evaluation pipelines
infra/           -> terraform placeholders
ci_cd/           -> cloud build pipeline

## Quick Start

1. Install dependencies

pip install -r requirements.txt

2. Configure environment variables

export PROJECT_ID=<your-project>
export DATASET_ID=agent_eval

3. Run evaluation

python pipelines/run_evaluation.py