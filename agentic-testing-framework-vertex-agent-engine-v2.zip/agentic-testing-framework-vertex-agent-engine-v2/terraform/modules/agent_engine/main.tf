
resource "google_vertex_ai_endpoint" "agent_endpoint" {
  name     = "enterprise-agent-endpoint"
  location = var.region
}

variable "region" {}
