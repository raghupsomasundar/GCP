
module "agent_engine" {
  source = "../../modules/agent_engine"
  region = "us-central1"
}
