
from src.agent_engine.client import VertexAgentEngineClient

def test_agent_engine_math():
    client = VertexAgentEngineClient()
    response = client.invoke("What is 7 + 8?")
    assert "15" in str(response)
