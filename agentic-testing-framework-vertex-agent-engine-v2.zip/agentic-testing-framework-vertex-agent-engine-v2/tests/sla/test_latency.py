
from src.observability.sla import validate_latency

def test_latency():
    assert validate_latency(3.2, threshold=5.0)
