
from locust import HttpUser, task

class AgentLoadTest(HttpUser):

    @task
    def invoke_agent(self):
        self.client.post("/", json={"input": "Hello Agent"})
