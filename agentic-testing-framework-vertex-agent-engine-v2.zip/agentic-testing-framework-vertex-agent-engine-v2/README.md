
# Vertex AI Agent Engine - Enterprise Testing Framework V2

Enterprise-grade testing framework tailored for Vertex AI Agent Engine.

Includes:
- Agent Engine client wrapper
- Security & prompt injection validation
- Tool call validation
- SLA latency checks
- Regression suite
- Dev/Prod Terraform modules
- CI/CD pipeline
- Load testing harness

Usage:

export AGENT_ENGINE_ENDPOINT=<your-endpoint>
pytest
