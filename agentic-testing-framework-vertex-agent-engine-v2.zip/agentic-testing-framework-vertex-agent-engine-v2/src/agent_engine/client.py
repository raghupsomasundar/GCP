
import os
import requests
from google.auth.transport.requests import Request
from google.oauth2 import service_account
from google.auth import default

class VertexAgentEngineClient:

    def __init__(self):
        self.endpoint = os.getenv("AGENT_ENGINE_ENDPOINT")
        credentials, _ = default()
        credentials.refresh(Request())
        self.token = credentials.token

    def invoke(self, user_input: str):
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

        payload = {"input": user_input}

        response = requests.post(self.endpoint, headers=headers, json=payload)
        response.raise_for_status()

        return response.json()
