
class AgentEvaluator:

    def validate_response_contains(self, response: dict, expected: str):
        return expected.lower() in response.get("output", "").lower()

    def validate_tool_call(self, response: dict, tool_name: str):
        tools = response.get("tool_calls", [])
        return any(tool.get("name") == tool_name for tool in tools)
