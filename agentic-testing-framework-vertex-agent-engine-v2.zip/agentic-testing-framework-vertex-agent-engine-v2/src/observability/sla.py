
def validate_latency(response_time: float, threshold: float = 5.0):
    return response_time <= threshold
