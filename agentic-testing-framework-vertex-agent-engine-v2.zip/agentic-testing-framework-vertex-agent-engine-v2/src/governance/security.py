
import re

class SecurityValidator:

    def detect_prompt_injection(self, text: str):
        patterns = ["ignore previous", "reveal password", "admin access"]
        return any(p in text.lower() for p in patterns)

    def detect_pii(self, text: str):
        ssn_pattern = r"\b\d{3}-\d{2}-\d{4}\b"
        return re.search(ssn_pattern, text) is not None
