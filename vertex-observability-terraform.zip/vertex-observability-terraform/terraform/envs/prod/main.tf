
terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

module "bigquery" {
  source     = "../../modules/bigquery"
  project_id = var.project_id
  location   = var.bq_location
}

module "log_sinks" {
  source     = "../../modules/log_sinks"
  project_id = var.project_id
  dataset_id = module.bigquery.dataset_id
}

module "iam" {
  source     = "../../modules/iam"
  project_id = var.project_id
}

module "pubsub" {
  source     = "../../modules/pubsub"
  project_id = var.project_id
}

module "cloud_function" {
  source          = "../../modules/cloud_function"
  project_id      = var.project_id
  region          = var.region
  service_account = module.iam.metric_sa_email
  topic_name      = module.pubsub.topic_name
  bq_dataset      = module.bigquery.dataset_id
}
