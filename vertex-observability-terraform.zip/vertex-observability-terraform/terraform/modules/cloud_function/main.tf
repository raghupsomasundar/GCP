
resource "google_storage_bucket" "src" {
  name     = "${var.project_id}-metric-fn-src"
  location = var.region
}

resource "google_storage_bucket_object" "src" {
  bucket = google_storage_bucket.src.name
  name   = "function.zip"
  source = "${path.module}/../../../function_src/function.zip"
}

resource "google_cloudfunctions2_function" "exporter" {
  name     = "vertex-metric-exporter"
  location = var.region

  build_config {
    runtime     = "python310"
    entry_point = "export_metrics"
    source {
      storage_source {
        bucket = google_storage_bucket.src.name
        object = google_storage_bucket_object.src.name
      }
    }
  }

  service_config {
    service_account_email = var.service_account
    environment_variables = {
      PROJECT_ID = var.project_id
      BQ_DATASET = var.bq_dataset
    }
  }

  event_trigger {
    event_type   = "google.cloud.pubsub.topic.v1.messagePublished"
    pubsub_topic = "projects/${var.project_id}/topics/${var.topic_name}"
  }
}
