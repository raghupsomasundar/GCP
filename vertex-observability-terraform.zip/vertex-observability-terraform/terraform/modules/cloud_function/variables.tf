
variable "project_id" {}
variable "region" {}
variable "service_account" {}
variable "topic_name" {}
variable "bq_dataset" {}
