
resource "google_logging_project_sink" "vertex" {
  name        = "vertex-ai-bq-sink"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = "resource.type=(\"aiplatform.googleapis.com/Endpoint\" OR \"notebook_instance\" OR \"cloud_run_revision\")"
}

resource "google_logging_project_sink" "trace" {
  name        = "trace-bq-sink"
  destination = "bigquery.googleapis.com/projects/${var.project_id}/datasets/${var.dataset_id}"
  filter      = "trace:*"
}
