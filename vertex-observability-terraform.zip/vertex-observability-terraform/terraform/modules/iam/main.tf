
resource "google_service_account" "metric_sa" {
  account_id   = "vertex-metric-export-sa"
  display_name = "Vertex Metric Exporter"
}

resource "google_project_iam_member" "monitoring" {
  project = var.project_id
  role    = "roles/monitoring.viewer"
  member  = "serviceAccount:${google_service_account.metric_sa.email}"
}

resource "google_project_iam_member" "bq" {
  project = var.project_id
  role    = "roles/bigquery.dataEditor"
  member  = "serviceAccount:${google_service_account.metric_sa.email}"
}

resource "google_project_iam_member" "secrets" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.metric_sa.email}"
}

output "metric_sa_email" {
  value = google_service_account.metric_sa.email
}
