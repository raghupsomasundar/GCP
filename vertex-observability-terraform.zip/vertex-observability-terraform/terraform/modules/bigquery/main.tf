
resource "google_bigquery_dataset" "obs" {
  dataset_id = "vertex_observability"
  project    = var.project_id
  location   = var.location
}

output "dataset_id" {
  value = google_bigquery_dataset.obs.dataset_id
}
