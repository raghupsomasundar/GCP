
resource "google_pubsub_topic" "trigger" {
  name = "vertex-metric-trigger"
}

output "topic_name" {
  value = google_pubsub_topic.trigger.name
}
