
# Vertex Observability – Terraform + GitHub Actions

## Features
- No Docker
- Cloud Logging → BigQuery
- Monitoring metrics → Cloud Functions Gen2 → BigQuery
- GitHub Actions with Workload Identity Federation

## Deploy
Push to main branch to trigger terraform apply.
