
from google.cloud import monitoring_v3, bigquery
from datetime import datetime, timedelta
import os

def export_metrics(event, context):
    project = os.environ["PROJECT_ID"]
    dataset = os.environ["BQ_DATASET"]
    mc = monitoring_v3.MetricServiceClient()
    bq = bigquery.Client()
    now = datetime.utcnow()

    interval = monitoring_v3.TimeInterval({
        "start_time": {"seconds": int((now - timedelta(minutes=5)).timestamp())},
        "end_time": {"seconds": int(now.timestamp())}
    })

    metrics = [
        "aiplatform.googleapis.com/prediction/count",
        "aiplatform.googleapis.com/prediction/latency"
    ]

    rows = []
    for m in metrics:
        for ts in mc.list_time_series(
            request={
                "name": f"projects/{project}",
                "filter": f'metric.type="{m}"',
                "interval": interval,
                "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL
            }
        ):
            for p in ts.points:
                rows.append({
                    "metric_timestamp": p.interval.end_time,
                    "metric_type": m,
                    "metric_value": p.value.double_value or p.value.int64_value
                })

    if rows:
        bq.insert_rows_json(f"{project}.{dataset}.infrastructure_metrics", rows)
