
import os
import uuid
import time
from flask import Flask, request
from google.cloud import monitoring_v3
from google.cloud import aiplatform
from vertexai.generative_models import GenerativeModel
from bq_logger import write_log

app = Flask(__name__)

PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
aiplatform.init(project=PROJECT_ID)
model = GenerativeModel("gemini-1.5-pro")

monitoring_client = monitoring_v3.MetricServiceClient()
project_name = f"projects/{PROJECT_ID}"

def write_custom_metric(metric_type, value):
    series = monitoring_v3.TimeSeries()
    series.metric.type = f"custom.googleapis.com/agent/{metric_type}"
    series.resource.type = "global"

    point = series.points.add()
    point.value.double_value = value
    point.interval.end_time.seconds = int(time.time())

    monitoring_client.create_time_series(
        name=project_name,
        time_series=[series]
    )

@app.route("/")
def run_agent():
    session_id = request.headers.get("X-Session-Id", str(uuid.uuid4()))
    step = "llm_call"
    prompt = request.args.get("q", "Hello")

    start = time.time()
    response = model.generate_content(prompt)
    latency = (time.time() - start) * 1000

    model_name = "gemini-1.5-pro"
    token_input = len(prompt.split())
    token_output = len(response.text.split())

    payload = {
        "session_id": session_id,
        "step": step,
        "model_name": model_name,
        "latency_ms": latency,
        "token_input": token_input,
        "token_output": token_output,
        "response": response.text
    }

    write_log(payload)
    write_custom_metric("latency", latency)

    return response.text
