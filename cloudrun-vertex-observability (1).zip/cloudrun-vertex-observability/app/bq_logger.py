
from google.cloud import bigquery
import os
import uuid
from datetime import datetime

PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
DATASET = os.getenv("BQ_DATASET", "agent_observability")
TABLE = os.getenv("BQ_TABLE", "agent_logs")

client = bigquery.Client()

def write_log(payload: dict):
    table_id = f"{PROJECT_ID}.{DATASET}.{TABLE}"
    payload["log_id"] = str(uuid.uuid4())
    payload["timestamp"] = datetime.utcnow().isoformat()

    errors = client.insert_rows_json(table_id, [payload])
    if errors:
        print("BigQuery insert errors:", errors)
