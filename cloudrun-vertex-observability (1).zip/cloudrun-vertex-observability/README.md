
# Cloud Run + Vertex AI + BigQuery Observability

## 1. Deploy Infrastructure
cd terraform
terraform init
terraform apply -var="project_id=YOUR_PROJECT" -var="region=asia-south1" -var="run_sa=CLOUD_RUN_SA_EMAIL"

## 2. Deploy Application
gcloud builds submit --tag gcr.io/YOUR_PROJECT/agent-service ./app

gcloud run deploy agent-service   --image gcr.io/YOUR_PROJECT/agent-service   --platform managed   --region asia-south1   --service-account CLOUD_RUN_SA_EMAIL   --set-env-vars GOOGLE_CLOUD_PROJECT=YOUR_PROJECT

## 3. Default Vertex Metrics (Auto Available)
- aiplatform.googleapis.com/endpoint/prediction_count
- aiplatform.googleapis.com/endpoint/prediction_latency
- aiplatform.googleapis.com/endpoint/error_count

View in Monitoring → Metrics Explorer
