
provider "google" {
  project = var.project_id
  region  = var.region
}

resource "google_bigquery_dataset" "dataset" {
  dataset_id = "agent_observability"
  location   = var.region
}

resource "google_bigquery_table" "table" {
  dataset_id = google_bigquery_dataset.dataset.dataset_id
  table_id   = "agent_logs"

  schema = jsonencode([
    {"name":"log_id","type":"STRING"},
    {"name":"timestamp","type":"TIMESTAMP"},
    {"name":"session_id","type":"STRING"},
    {"name":"step","type":"STRING"},
    {"name":"model_name","type":"STRING"},
    {"name":"latency_ms","type":"FLOAT"},
    {"name":"token_input","type":"INTEGER"},
    {"name":"token_output","type":"INTEGER"},
    {"name":"response","type":"STRING"}
  ])
}

resource "google_project_iam_member" "run_bq" {
  project = var.project_id
  role    = "roles/bigquery.dataEditor"
  member  = "serviceAccount:${var.run_sa}"
}
